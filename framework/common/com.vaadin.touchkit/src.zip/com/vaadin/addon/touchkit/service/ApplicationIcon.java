package com.vaadin.addon.touchkit.service;

public interface ApplicationIcon {
	String getSizes();
	String getHref();
	boolean isPreComposed();
}
