package com.vaadin.addon.touchkit.gwt.client;

import com.google.gwt.i18n.client.Constants;

public interface OfflineModeMessages extends Constants {

    String serverCannotBeReachedMsg();

    String tryAgainMsg();

    String offlineDueToNetworkMsg();

}
