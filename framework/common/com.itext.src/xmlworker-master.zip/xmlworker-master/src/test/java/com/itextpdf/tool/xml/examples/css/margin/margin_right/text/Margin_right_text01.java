package com.itextpdf.tool.xml.examples.css.margin.margin_right.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_right_text01 extends SampleTest {
    protected String getTestName() {
        return  "margin_right_text01";
    }
}
