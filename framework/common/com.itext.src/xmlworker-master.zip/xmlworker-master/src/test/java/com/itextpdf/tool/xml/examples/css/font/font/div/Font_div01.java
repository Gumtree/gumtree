package com.itextpdf.tool.xml.examples.css.font.font.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_div01 extends SampleTest {
    protected String getTestName() {
        return  "font_div01";
    }
}
