package com.itextpdf.tool.xml.examples.css.font.font_style.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_style_table01 extends SampleTest {
    protected String getTestName() {
        return  "font_style_table01";
    }
}
