package com.itextpdf.tool.xml.examples.css.height.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Height_table01 extends SampleTest {
    protected String getTestName() {
        return  "height_table01";
    }
}
