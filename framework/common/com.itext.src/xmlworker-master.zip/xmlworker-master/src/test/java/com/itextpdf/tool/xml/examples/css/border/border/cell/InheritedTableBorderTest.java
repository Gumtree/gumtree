package com.itextpdf.tool.xml.examples.css.border.border.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class InheritedTableBorderTest extends SampleTest {
    protected String getTestName() {
        return "inheritedTableBorder";
    }
}
