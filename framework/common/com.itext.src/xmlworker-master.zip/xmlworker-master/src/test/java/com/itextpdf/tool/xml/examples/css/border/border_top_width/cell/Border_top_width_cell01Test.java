package com.itextpdf.tool.xml.examples.css.border.border_top_width.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_top_width_cell01Test extends SampleTest {
    protected String getTestName() {
        return  "border_top_width_cell01";
    }
}
