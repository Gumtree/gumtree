package com.itextpdf.tool.xml.examples.css.page_break.before.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Before_list01 extends SampleTest {
    protected String getTestName() {
        return  "before_list01";
    }
}
