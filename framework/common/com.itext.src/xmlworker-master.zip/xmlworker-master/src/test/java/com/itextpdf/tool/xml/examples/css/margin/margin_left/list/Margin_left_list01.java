package com.itextpdf.tool.xml.examples.css.margin.margin_left.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_left_list01 extends SampleTest {
    protected String getTestName() {
        return  "margin_left_list01";
    }
}
