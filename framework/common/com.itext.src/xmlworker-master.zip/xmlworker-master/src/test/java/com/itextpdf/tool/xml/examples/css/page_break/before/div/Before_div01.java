package com.itextpdf.tool.xml.examples.css.page_break.before.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Before_div01 extends SampleTest {
    protected String getTestName() {
        return  "before_div01";
    }
}
