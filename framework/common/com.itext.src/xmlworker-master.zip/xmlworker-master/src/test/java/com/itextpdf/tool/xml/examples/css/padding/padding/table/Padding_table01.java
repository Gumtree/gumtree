package com.itextpdf.tool.xml.examples.css.padding.padding.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_table01 extends SampleTest {
    protected String getTestName() {
        return  "padding_table01";
    }
}
