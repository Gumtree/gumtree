package com.itextpdf.tool.xml.examples.css.caption_side.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Caption_side_table01 extends SampleTest {
    protected String getTestName() {
        return  "caption_side_table01";
    }
}
