package com.itextpdf.tool.xml.examples.css.padding.padding_left.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_left_cell01 extends SampleTest {
    protected String getTestName() {
        return  "padding_left_cell01";
    }
}
