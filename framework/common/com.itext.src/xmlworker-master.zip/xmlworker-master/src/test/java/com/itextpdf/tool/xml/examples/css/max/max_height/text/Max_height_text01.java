package com.itextpdf.tool.xml.examples.css.max.max_height.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Max_height_text01 extends SampleTest {
    protected String getTestName() {
        return  "max_height_text01";
    }
}
