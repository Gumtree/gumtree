package com.itextpdf.tool.xml.examples.css.padding.padding.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_cell01 extends SampleTest {
    protected String getTestName() {
        return  "padding_cell01";
    }
}
