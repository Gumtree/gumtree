package com.itextpdf.tool.xml.examples.css.page_break.after.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class After_text01 extends SampleTest {
    protected String getTestName() {
        return  "after_text01";
    }
}
