package com.itextpdf.tool.xml.examples.css.font.font_weight.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_weight_div01 extends SampleTest {
    protected String getTestName() {
        return  "font_weight_div01";
    }
}
