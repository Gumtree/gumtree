package com.itextpdf.tool.xml.examples.css.page_break.after.img;

import com.itextpdf.tool.xml.examples.SampleTest;

public class After_img01 extends SampleTest {
    protected String getTestName() {
        return  "after_img01";
    }
}
