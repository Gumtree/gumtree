package com.itextpdf.tool.xml.examples.css.page_break.after.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class After_list01 extends SampleTest {
    protected String getTestName() {
        return  "after_list01";
    }
}
