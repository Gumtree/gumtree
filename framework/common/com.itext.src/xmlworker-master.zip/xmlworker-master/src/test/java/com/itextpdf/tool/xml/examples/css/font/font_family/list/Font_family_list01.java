package com.itextpdf.tool.xml.examples.css.font.font_family.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_family_list01 extends SampleTest {
    protected String getTestName() {
        return  "font_family_list01";
    }
}
