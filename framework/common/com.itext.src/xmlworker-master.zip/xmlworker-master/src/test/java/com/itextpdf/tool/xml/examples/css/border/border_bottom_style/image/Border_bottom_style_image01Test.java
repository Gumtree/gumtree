package com.itextpdf.tool.xml.examples.css.border.border_bottom_style.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_bottom_style_image01Test extends SampleTest {
    protected String getTestName() {
        return  "border_bottom_style_image01";
    }
}
