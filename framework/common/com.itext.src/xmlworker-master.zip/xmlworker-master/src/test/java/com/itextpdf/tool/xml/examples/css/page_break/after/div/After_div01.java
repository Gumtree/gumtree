package com.itextpdf.tool.xml.examples.css.page_break.after.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class After_div01 extends SampleTest {
    protected String getTestName() {
        return  "after_div01";
    }
}
