package com.itextpdf.tool.xml.examples.css.border.border_bottom.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_bottom_list02Test extends SampleTest {
    protected String getTestName() {
        return  "border_bottom_list02";
    }
}
