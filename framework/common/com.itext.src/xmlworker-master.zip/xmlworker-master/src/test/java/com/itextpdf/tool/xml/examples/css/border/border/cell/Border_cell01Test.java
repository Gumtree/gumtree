package com.itextpdf.tool.xml.examples.css.border.border.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_cell01Test extends SampleTest {
    protected String getTestName() {
        return  "border_cell01";
    }
}
