package com.itextpdf.tool.xml.examples.css.text.align.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Align_div01 extends SampleTest {
    protected String getTestName() {
        return  "align_div01";
    }
}
