package com.itextpdf.tool.xml.examples.css.height.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Height_div01 extends SampleTest {
    protected String getTestName() {
        return  "height_div01";
    }
}
