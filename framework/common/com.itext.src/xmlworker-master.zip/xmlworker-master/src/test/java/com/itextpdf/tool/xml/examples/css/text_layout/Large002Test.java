package com.itextpdf.tool.xml.examples.css.text_layout;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Large002Test extends SampleTest {
    protected String getTestName() {
        return  "large002";
    }
}
