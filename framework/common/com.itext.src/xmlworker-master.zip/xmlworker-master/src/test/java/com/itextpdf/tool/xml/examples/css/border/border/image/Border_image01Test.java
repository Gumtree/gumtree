package com.itextpdf.tool.xml.examples.css.border.border.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_image01Test extends SampleTest {
    protected String getTestName() {
        return  "border_image01";
    }
}
