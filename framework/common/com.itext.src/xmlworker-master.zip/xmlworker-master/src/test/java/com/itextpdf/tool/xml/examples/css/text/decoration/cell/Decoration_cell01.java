package com.itextpdf.tool.xml.examples.css.text.decoration.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Decoration_cell01 extends SampleTest {
    protected String getTestName() {
        return  "decoration_cell01";
    }
}
