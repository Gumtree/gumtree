package com.itextpdf.tool.xml.examples.css.color.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Color_cell01 extends SampleTest {
    protected String getTestName() {
        return  "color_cell01";
    }
}
