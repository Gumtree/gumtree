package com.itextpdf.tool.xml.examples.css.text.indent.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Indent_text01 extends SampleTest {
    protected String getTestName() {
        return  "indent_text01";
    }
}
