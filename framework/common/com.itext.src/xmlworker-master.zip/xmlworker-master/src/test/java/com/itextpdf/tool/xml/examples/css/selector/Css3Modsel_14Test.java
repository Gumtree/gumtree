package com.itextpdf.tool.xml.examples.css.selector;

import com.itextpdf.tool.xml.examples.SampleTest;
import org.junit.Ignore;

//issue with border of p element
@Ignore
public class Css3Modsel_14Test extends SampleTest {
    protected String getTestName() {
        return  "css3-modsel-14";
    }
}
