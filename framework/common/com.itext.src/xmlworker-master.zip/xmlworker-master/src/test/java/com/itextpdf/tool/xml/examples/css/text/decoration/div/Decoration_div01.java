package com.itextpdf.tool.xml.examples.css.text.decoration.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Decoration_div01 extends SampleTest {
    protected String getTestName() {
        return  "decoration_div01";
    }
}
