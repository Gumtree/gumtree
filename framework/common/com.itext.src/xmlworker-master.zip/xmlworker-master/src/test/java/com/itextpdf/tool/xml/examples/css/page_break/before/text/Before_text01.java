package com.itextpdf.tool.xml.examples.css.page_break.before.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Before_text01 extends SampleTest {
    protected String getTestName() {
        return  "before_text01";
    }
}
