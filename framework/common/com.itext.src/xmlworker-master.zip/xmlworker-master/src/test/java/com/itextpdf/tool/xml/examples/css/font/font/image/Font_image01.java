package com.itextpdf.tool.xml.examples.css.font.font.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_image01 extends SampleTest {
    protected String getTestName() {
        return  "font_image01";
    }
}
