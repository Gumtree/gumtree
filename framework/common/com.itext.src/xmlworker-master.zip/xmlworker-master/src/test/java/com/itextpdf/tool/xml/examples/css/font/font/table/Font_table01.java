package com.itextpdf.tool.xml.examples.css.font.font.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_table01 extends SampleTest {
    protected String getTestName() {
        return  "font_table01";
    }
}
