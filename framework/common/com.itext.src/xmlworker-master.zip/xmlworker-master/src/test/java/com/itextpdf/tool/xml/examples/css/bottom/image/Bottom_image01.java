package com.itextpdf.tool.xml.examples.css.bottom.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Bottom_image01 extends SampleTest {
    protected String getTestName() {
        return  "bottom_image01";
    }
}
