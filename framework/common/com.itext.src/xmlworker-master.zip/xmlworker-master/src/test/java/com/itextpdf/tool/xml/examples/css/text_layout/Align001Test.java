package com.itextpdf.tool.xml.examples.css.text_layout;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Align001Test extends SampleTest {
    protected String getTestName() {
        return  "align001";
    }
}
