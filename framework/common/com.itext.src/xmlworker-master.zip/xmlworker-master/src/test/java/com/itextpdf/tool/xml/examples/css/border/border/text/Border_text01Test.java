package com.itextpdf.tool.xml.examples.css.border.border.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_text01Test extends SampleTest {
    protected String getTestName() {
        return  "border_text01";
    }
}
