package com.itextpdf.tool.xml.examples.css.font.font_weight.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_weight_text01 extends SampleTest {
    protected String getTestName() {
        return  "font_weight_text01";
    }
}
