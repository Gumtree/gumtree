package com.itextpdf.tool.xml.examples.css.list_style.list_style_type.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class List_style_type_list01 extends SampleTest {
    protected String getTestName() {
        return  "list_style_type_list01";
    }
}
