package com.itextpdf.tool.xml.examples.css.font.font_size.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_size_text01 extends SampleTest {
    protected String getTestName() {
        return  "font_size_text01";
    }
}
