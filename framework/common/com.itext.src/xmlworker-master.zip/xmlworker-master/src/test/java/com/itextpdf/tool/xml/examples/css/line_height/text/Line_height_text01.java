package com.itextpdf.tool.xml.examples.css.line_height.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Line_height_text01 extends SampleTest {
    protected String getTestName() {
        return  "line_height_text01";
    }
}
