package com.itextpdf.tool.xml.examples.css.position;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Overflow01Test extends SampleTest {
    protected String getTestName() {
        return  "overflow01";
    }
}
