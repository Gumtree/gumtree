package com.itextpdf.tool.xml.examples.css.border.border_right_width.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_right_width_table01Test extends SampleTest {
    protected String getTestName() {
        return  "border_right_width_table01";
    }
}
