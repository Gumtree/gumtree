package com.itextpdf.tool.xml.examples.css.text.decoration.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Decoration_text01 extends SampleTest {
    protected String getTestName() {
        return  "decoration_text01";
    }
}
