package com.itextpdf.tool.xml.examples.css.background.background_color.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Background_color_imagel01Test extends SampleTest {
    protected String getTestName() {
        return  "background_color_image01";
    }
}
