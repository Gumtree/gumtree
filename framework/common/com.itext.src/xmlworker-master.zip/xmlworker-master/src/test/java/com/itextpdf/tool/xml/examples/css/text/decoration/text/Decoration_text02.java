package com.itextpdf.tool.xml.examples.css.text.decoration.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Decoration_text02 extends SampleTest {
    @Override
    protected String getTestName() {
        return "decoration_text02";
    }
}
