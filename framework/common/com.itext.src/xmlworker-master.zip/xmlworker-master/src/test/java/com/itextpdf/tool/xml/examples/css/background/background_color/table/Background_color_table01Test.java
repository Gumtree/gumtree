package com.itextpdf.tool.xml.examples.css.background.background_color.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Background_color_table01Test extends SampleTest {
    protected String getTestName() {
        return  "background_color_table01";
    }
}
