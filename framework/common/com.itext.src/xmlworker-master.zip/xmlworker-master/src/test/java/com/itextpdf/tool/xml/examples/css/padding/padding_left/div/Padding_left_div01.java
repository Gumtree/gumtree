package com.itextpdf.tool.xml.examples.css.padding.padding_left.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_left_div01 extends SampleTest {
    protected String getTestName() {
        return  "padding_left_div01";
    }
}
