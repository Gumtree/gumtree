package com.itextpdf.tool.xml.examples.css.margin.margin.table;

import com.itextpdf.tool.xml.examples.SampleTest;
import org.junit.Ignore;

@Ignore
public class Margin_table01 extends SampleTest {
    protected String getTestName() {
        return  "margin_table01";
    }
}
