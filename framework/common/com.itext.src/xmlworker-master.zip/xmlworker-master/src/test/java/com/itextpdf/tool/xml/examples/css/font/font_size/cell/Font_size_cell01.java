package com.itextpdf.tool.xml.examples.css.font.font_size.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_size_cell01 extends SampleTest {
    protected String getTestName() {
        return  "font_size_cell01";
    }
}
