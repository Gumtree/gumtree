package com.itextpdf.tool.xml.examples.css.font.font_variant.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_variant_text01 extends SampleTest {
    protected String getTestName() {
        return  "font_variant_text01";
    }
}
