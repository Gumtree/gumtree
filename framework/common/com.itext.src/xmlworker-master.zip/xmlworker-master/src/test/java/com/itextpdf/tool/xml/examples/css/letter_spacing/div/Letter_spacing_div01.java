package com.itextpdf.tool.xml.examples.css.letter_spacing.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Letter_spacing_div01 extends SampleTest {
    protected String getTestName() {
        return  "letter_spacing_div01";
    }
}
