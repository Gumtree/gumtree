package com.itextpdf.tool.xml.examples.css.text.align.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Align_text01 extends SampleTest {
    protected String getTestName() {
        return  "align_text01";
    }
}
