package com.itextpdf.tool.xml.examples.css.text_layout;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Height008Test extends SampleTest {
    protected String getTestName() {
        return  "height008";
    }
}
