package com.itextpdf.tool.xml.examples.css.border.border_collapse.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_collapse_table01Test extends SampleTest {
    protected String getTestName() {
        return  "border_collapse_table01";
    }
}
