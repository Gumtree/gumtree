package com.itextpdf.tool.xml.examples.css.bottom.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Bottom_text01 extends SampleTest {
    protected String getTestName() {
        return  "bottom_text01";
    }
}
