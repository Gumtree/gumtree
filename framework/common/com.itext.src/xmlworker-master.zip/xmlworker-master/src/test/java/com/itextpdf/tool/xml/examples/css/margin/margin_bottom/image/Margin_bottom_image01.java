package com.itextpdf.tool.xml.examples.css.margin.margin_bottom.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_bottom_image01 extends SampleTest {
    protected String getTestName() {
        return  "margin_bottom_image01";
    }
}
