package com.itextpdf.tool.xml.examples.css.font.font_weight.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_weight_list01 extends SampleTest {
    protected String getTestName() {
        return  "font_weight_list01";
    }
}
