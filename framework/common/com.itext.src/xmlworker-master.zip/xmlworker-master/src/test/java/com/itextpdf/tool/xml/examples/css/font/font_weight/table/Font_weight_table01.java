package com.itextpdf.tool.xml.examples.css.font.font_weight.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_weight_table01 extends SampleTest {
    protected String getTestName() {
        return  "font_weight_table01";
    }
}
