package com.itextpdf.tool.xml.examples.css.border.border_left_width.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_left_width_table01Test extends SampleTest {
    protected String getTestName() {
        return  "border_left_width_table01";
    }
}
