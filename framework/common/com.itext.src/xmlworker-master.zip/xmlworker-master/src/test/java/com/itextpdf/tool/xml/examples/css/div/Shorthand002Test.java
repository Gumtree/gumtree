package com.itextpdf.tool.xml.examples.css.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Shorthand002Test extends SampleTest {
    protected String getTestName() {
        return  "shorthand002";
    }
}