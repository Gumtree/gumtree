package com.itextpdf.tool.xml.examples.css.color.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Color_list01 extends SampleTest {
    protected String getTestName() {
        return  "color_list01";
    }
}
