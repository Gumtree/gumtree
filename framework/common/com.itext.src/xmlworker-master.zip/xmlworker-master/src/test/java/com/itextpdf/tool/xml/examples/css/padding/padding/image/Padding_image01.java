package com.itextpdf.tool.xml.examples.css.padding.padding.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_image01 extends SampleTest {
    protected String getTestName() {
        return  "padding_image01";
    }
}
