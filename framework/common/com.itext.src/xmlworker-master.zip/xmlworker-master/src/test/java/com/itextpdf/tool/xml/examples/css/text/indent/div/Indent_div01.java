package com.itextpdf.tool.xml.examples.css.text.indent.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Indent_div01 extends SampleTest {
    protected String getTestName() {
        return  "indent_div01";
    }
}
