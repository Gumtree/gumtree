package com.itextpdf.tool.xml.examples.css.selector;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Css3Modsel_154Test extends SampleTest {
    protected String getTestName() {
        return  "css3-modsel-154";
    }
}
