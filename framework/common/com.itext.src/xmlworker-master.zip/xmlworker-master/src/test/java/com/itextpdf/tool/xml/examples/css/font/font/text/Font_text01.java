package com.itextpdf.tool.xml.examples.css.font.font.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_text01 extends SampleTest {
    protected String getTestName() {
        return  "font_text01";
    }
}
