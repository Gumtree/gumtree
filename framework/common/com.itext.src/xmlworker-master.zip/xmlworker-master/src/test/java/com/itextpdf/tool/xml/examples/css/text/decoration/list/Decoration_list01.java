package com.itextpdf.tool.xml.examples.css.text.decoration.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Decoration_list01 extends SampleTest {
    protected String getTestName() {
        return  "decoration_list01";
    }
}
