package com.itextpdf.tool.xml.examples.css.padding.padding.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_text01 extends SampleTest {
    protected String getTestName() {
        return  "padding_text01";
    }
}
