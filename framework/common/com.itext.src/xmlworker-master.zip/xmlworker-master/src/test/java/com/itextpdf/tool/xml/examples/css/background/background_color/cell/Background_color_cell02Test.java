package com.itextpdf.tool.xml.examples.css.background.background_color.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Background_color_cell02Test extends SampleTest {
    protected String getTestName() {
        return  "background_color_cell02";
    }
}
