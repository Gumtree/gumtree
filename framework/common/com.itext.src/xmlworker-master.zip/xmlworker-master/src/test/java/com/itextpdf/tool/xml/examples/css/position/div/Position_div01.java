package com.itextpdf.tool.xml.examples.css.position.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Position_div01 extends SampleTest {
    protected String getTestName() {
        return  "position_div01";
    }
}
