package com.itextpdf.tool.xml.examples.css.border.border_spacing.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_spacing_cell01Test extends SampleTest {
    protected String getTestName() {
        return  "border_spacing_cell01";
    }
}
