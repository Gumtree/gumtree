package com.itextpdf.tool.xml.examples.css.text.decoration.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Decoration_table01 extends SampleTest {
    protected String getTestName() {
        return  "decoration_table01";
    }
}
