package com.itextpdf.tool.xml.examples.css.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Match006Test extends SampleTest {
    protected String getTestName() {
        return  "match006";
    }
}
