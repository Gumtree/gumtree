package com.itextpdf.tool.xml.examples.css.height.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Height_cell01 extends SampleTest {
    protected String getTestName() {
        return  "height_cell01";
    }
}
