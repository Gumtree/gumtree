package com.itextpdf.tool.xml.examples.css.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Overflow02Test extends SampleTest {
    protected String getTestName() {
        return  "overflow02";
    }
}
