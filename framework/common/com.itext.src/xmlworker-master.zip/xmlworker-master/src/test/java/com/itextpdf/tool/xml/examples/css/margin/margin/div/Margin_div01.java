package com.itextpdf.tool.xml.examples.css.margin.margin.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_div01 extends SampleTest {
    protected String getTestName() {
        return  "margin_div01";
    }
}
