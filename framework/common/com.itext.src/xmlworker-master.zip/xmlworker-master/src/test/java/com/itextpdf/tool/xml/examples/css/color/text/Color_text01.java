package com.itextpdf.tool.xml.examples.css.color.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Color_text01 extends SampleTest {
    protected String getTestName() {
        return  "color_text01";
    }
}
