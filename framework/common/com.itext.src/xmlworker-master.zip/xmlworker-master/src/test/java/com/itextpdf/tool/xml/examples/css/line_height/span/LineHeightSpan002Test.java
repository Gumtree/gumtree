package com.itextpdf.tool.xml.examples.css.line_height.span;

import com.itextpdf.tool.xml.examples.SampleTest;

public class LineHeightSpan002Test extends SampleTest {
    protected String getTestName() {
        return "lineHeightSpan002";
    }

}
