package com.itextpdf.tool.xml.examples.css.padding.padding_right.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_right_div01 extends SampleTest {
    protected String getTestName() {
        return  "padding_right_div01";
    }
}
