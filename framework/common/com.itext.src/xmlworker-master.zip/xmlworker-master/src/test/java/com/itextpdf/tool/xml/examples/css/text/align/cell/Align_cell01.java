package com.itextpdf.tool.xml.examples.css.text.align.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Align_cell01 extends SampleTest {
    protected String getTestName() {
        return  "align_cell01";
    }
}
