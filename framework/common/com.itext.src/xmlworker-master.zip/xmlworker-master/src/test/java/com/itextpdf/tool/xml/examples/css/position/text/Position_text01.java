package com.itextpdf.tool.xml.examples.css.position.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Position_text01 extends SampleTest {
    protected String getTestName() {
        return  "position_text01";
    }
}
