package com.itextpdf.tool.xml.examples.css.margin.margin.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_text01 extends SampleTest {
    protected String getTestName() {
        return  "margin_text01";
    }
}
