package com.itextpdf.tool.xml.examples.css.text.indent.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Indent_list01 extends SampleTest {
    protected String getTestName() {
        return  "indent_list01";
    }
}
