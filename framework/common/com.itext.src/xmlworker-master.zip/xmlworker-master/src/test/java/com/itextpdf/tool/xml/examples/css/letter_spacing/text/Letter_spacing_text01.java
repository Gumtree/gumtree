package com.itextpdf.tool.xml.examples.css.letter_spacing.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Letter_spacing_text01 extends SampleTest {
    protected String getTestName() {
        return  "letter_spacing_text01";
    }
}
