package com.itextpdf.tool.xml.examples.css.margin.margin_left.text;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_left_text01 extends SampleTest {
    protected String getTestName() {
        return  "margin_left_text01";
    }
}
