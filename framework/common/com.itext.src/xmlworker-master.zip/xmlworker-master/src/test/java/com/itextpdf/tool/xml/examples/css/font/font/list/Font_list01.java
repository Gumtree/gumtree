package com.itextpdf.tool.xml.examples.css.font.font.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_list01 extends SampleTest {
    protected String getTestName() {
        return  "font_list01";
    }
}
