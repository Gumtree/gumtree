package com.itextpdf.tool.xml.examples.css.padding.padding.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_list01 extends SampleTest {
    protected String getTestName() {
        return  "padding_list01";
    }
}
