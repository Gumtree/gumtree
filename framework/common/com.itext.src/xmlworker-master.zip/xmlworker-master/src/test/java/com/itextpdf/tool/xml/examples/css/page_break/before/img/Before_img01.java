package com.itextpdf.tool.xml.examples.css.page_break.before.img;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Before_img01 extends SampleTest {
    protected String getTestName() {
        return  "before_img01";
    }
}
