package com.itextpdf.tool.xml.examples.css.page_break.after.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class After_table01 extends SampleTest {
    protected String getTestName() {
        return  "after_table01";
    }
}
