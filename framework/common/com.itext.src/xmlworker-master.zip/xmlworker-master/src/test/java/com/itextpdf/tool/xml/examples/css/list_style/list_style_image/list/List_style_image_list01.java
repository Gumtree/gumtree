package com.itextpdf.tool.xml.examples.css.list_style.list_style_image.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class List_style_image_list01 extends SampleTest {
    protected String getTestName() {
        return  "list_style_image_list01";
    }
}
