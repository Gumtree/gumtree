package com.itextpdf.tool.xml.examples.css.padding.padding_top.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_top_div01 extends SampleTest {
    protected String getTestName() {
        return  "padding_top_div01";
    }
}
