package com.itextpdf.tool.xml.examples.css.border.border.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_div01Test extends SampleTest {
    protected String getTestName() {
        return  "border_div01";
    }
}
