package com.itextpdf.tool.xml.examples.css.border.border_left_color.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_left_color_cell01Test extends SampleTest {
    protected String getTestName() {
        return  "border_left_color_cell01";
    }
}
