package com.itextpdf.tool.xml.examples.css.text.align.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Align_table01 extends SampleTest {
    protected String getTestName() {
        return  "align_table01";
    }
}
