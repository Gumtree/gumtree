package com.itextpdf.tool.xml.examples.css.padding.padding_right.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_right_list01 extends SampleTest {
    protected String getTestName() {
        return  "padding_right_list01";
    }
}
