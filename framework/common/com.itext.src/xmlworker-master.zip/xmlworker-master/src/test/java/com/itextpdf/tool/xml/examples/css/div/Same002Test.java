package com.itextpdf.tool.xml.examples.css.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Same002Test extends SampleTest {
    protected String getTestName() {
        return  "same002";
    }
}