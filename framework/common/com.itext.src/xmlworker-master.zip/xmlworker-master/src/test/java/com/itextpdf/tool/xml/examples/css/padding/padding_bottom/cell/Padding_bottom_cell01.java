package com.itextpdf.tool.xml.examples.css.padding.padding_bottom.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_bottom_cell01 extends SampleTest {
    protected String getTestName() {
        return  "padding_bottom_cell01";
    }
}
