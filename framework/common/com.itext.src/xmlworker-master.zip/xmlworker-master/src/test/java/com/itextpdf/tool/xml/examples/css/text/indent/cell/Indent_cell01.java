package com.itextpdf.tool.xml.examples.css.text.indent.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Indent_cell01 extends SampleTest {
    protected String getTestName() {
        return  "indent_cell01";
    }
}
