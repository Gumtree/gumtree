package com.itextpdf.tool.xml.examples.css.color.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Color_table01 extends SampleTest {
    protected String getTestName() {
        return  "color_table01";
    }
}
