package com.itextpdf.tool.xml.examples.css.line_height.span;

import com.itextpdf.tool.xml.examples.SampleTest;

public class LineHeightSpan003Test extends SampleTest {
    protected String getTestName() {
        return "lineHeightSpan003";
    }
}
