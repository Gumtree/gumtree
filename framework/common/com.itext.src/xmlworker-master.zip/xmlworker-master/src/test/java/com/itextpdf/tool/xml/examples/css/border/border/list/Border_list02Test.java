package com.itextpdf.tool.xml.examples.css.border.border.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_list02Test extends SampleTest {
    protected String getTestName() {
        return  "border_list02";
    }
}
