package com.itextpdf.tool.xml.examples.css.border.border_top_color.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_top_color_cell01Test extends SampleTest {
    protected String getTestName() {
        return  "border_top_color_cell01";
    }
}
