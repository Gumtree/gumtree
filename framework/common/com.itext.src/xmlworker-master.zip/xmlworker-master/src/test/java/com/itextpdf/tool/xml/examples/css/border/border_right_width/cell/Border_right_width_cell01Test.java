package com.itextpdf.tool.xml.examples.css.border.border_right_width.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_right_width_cell01Test extends SampleTest {
    protected String getTestName() {
        return  "border_right_width_cell01";
    }
}
