package com.itextpdf.tool.xml.examples.css.border.border.list;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Border_list01Test extends SampleTest {
    protected String getTestName() {
        return  "border_list01";
    }
}
