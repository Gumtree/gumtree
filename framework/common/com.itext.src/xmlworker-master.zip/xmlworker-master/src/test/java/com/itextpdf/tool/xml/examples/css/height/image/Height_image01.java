package com.itextpdf.tool.xml.examples.css.height.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Height_image01 extends SampleTest {
    protected String getTestName() {
        return  "height_image01";
    }
}
