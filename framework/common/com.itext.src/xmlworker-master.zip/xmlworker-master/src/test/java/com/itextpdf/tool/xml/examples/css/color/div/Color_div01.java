package com.itextpdf.tool.xml.examples.css.color.div;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Color_div01 extends SampleTest {
    protected String getTestName() {
        return  "color_div01";
    }
}
