package com.itextpdf.tool.xml.examples.css.font.font.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Font_cell01 extends SampleTest {
    protected String getTestName() {
        return  "font_cell01";
    }
}
