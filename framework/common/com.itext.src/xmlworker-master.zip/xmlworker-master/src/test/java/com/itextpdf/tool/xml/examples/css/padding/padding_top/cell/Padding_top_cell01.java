package com.itextpdf.tool.xml.examples.css.padding.padding_top.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Padding_top_cell01 extends SampleTest {
    protected String getTestName() {
        return  "padding_top_cell01";
    }
}
