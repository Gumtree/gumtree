package com.itextpdf.tool.xml.examples.css.letter_spacing.table;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Letter_spacing_table01 extends SampleTest {
    protected String getTestName() {
        return  "letter_spacing_table01";
    }
}
