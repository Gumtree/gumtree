package com.itextpdf.tool.xml.examples.css.left.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Left_image01 extends SampleTest {
    protected String getTestName() {
        return  "left_image01";
    }
}
