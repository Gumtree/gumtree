package com.itextpdf.tool.xml.examples.css.selector;

import com.itextpdf.tool.xml.examples.SampleTest;
import org.junit.Ignore;

//escaped symbols
@Ignore
public class Css3Modsel_155dTest extends SampleTest {
    protected String getTestName() {
        return  "css3-modsel-155d";
    }
}
