package com.itextpdf.tool.xml.examples.css.margin.margin.image;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Margin_image01 extends SampleTest {
    protected String getTestName() {
        return  "margin_image01";
    }
}
