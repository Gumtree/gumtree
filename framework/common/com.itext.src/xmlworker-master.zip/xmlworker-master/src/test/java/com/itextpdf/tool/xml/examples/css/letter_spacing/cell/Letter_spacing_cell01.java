package com.itextpdf.tool.xml.examples.css.letter_spacing.cell;

import com.itextpdf.tool.xml.examples.SampleTest;

public class Letter_spacing_cell01 extends SampleTest {
    protected String getTestName() {
        return  "letter_spacing_cell01";
    }
}
