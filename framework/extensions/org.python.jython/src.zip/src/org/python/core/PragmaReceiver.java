package org.python.core;

public interface PragmaReceiver {
    void add(Pragma pragma);
}
