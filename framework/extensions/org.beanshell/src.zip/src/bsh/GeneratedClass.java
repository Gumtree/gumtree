package bsh;

/**
 * Marker interface for generated classes
 */
public interface GeneratedClass {

}
