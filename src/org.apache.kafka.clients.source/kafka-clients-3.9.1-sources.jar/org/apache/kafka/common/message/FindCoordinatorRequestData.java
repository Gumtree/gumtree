/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.common.message;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.apache.kafka.common.errors.UnsupportedVersionException;
import org.apache.kafka.common.protocol.ApiMessage;
import org.apache.kafka.common.protocol.MessageSizeAccumulator;
import org.apache.kafka.common.protocol.MessageUtil;
import org.apache.kafka.common.protocol.ObjectSerializationCache;
import org.apache.kafka.common.protocol.Readable;
import org.apache.kafka.common.protocol.Writable;
import org.apache.kafka.common.protocol.types.CompactArrayOf;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.protocol.types.RawTaggedField;
import org.apache.kafka.common.protocol.types.RawTaggedFieldWriter;
import org.apache.kafka.common.protocol.types.Schema;
import org.apache.kafka.common.protocol.types.Type;
import org.apache.kafka.common.utils.ByteUtils;

import static org.apache.kafka.common.protocol.types.Field.TaggedFieldsSection;


public class FindCoordinatorRequestData implements ApiMessage {
    String key;
    byte keyType;
    List<String> coordinatorKeys;
    private List<RawTaggedField> _unknownTaggedFields;
    
    public static final Schema SCHEMA_0 =
        new Schema(
            new Field("key", Type.STRING, "The coordinator key.")
        );
    
    public static final Schema SCHEMA_1 =
        new Schema(
            new Field("key", Type.STRING, "The coordinator key."),
            new Field("key_type", Type.INT8, "The coordinator key type. (Group, transaction, etc.)")
        );
    
    public static final Schema SCHEMA_2 = SCHEMA_1;
    
    public static final Schema SCHEMA_3 =
        new Schema(
            new Field("key", Type.COMPACT_STRING, "The coordinator key."),
            new Field("key_type", Type.INT8, "The coordinator key type. (Group, transaction, etc.)"),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema SCHEMA_4 =
        new Schema(
            new Field("key_type", Type.INT8, "The coordinator key type. (Group, transaction, etc.)"),
            new Field("coordinator_keys", new CompactArrayOf(Type.COMPACT_STRING), "The coordinator keys."),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema SCHEMA_5 = SCHEMA_4;
    
    public static final Schema SCHEMA_6 = SCHEMA_5;
    
    public static final Schema[] SCHEMAS = new Schema[] {
        SCHEMA_0,
        SCHEMA_1,
        SCHEMA_2,
        SCHEMA_3,
        SCHEMA_4,
        SCHEMA_5,
        SCHEMA_6
    };
    
    public static final short LOWEST_SUPPORTED_VERSION = 0;
    public static final short HIGHEST_SUPPORTED_VERSION = 6;
    
    public FindCoordinatorRequestData(Readable _readable, short _version) {
        read(_readable, _version);
    }
    
    public FindCoordinatorRequestData() {
        this.key = "";
        this.keyType = (byte) 0;
        this.coordinatorKeys = new ArrayList<String>(0);
    }
    
    @Override
    public short apiKey() {
        return 10;
    }
    
    @Override
    public short lowestSupportedVersion() {
        return 0;
    }
    
    @Override
    public short highestSupportedVersion() {
        return 6;
    }
    
    @Override
    public final void read(Readable _readable, short _version) {
        if (_version <= 3) {
            int length;
            if (_version >= 3) {
                length = _readable.readUnsignedVarint() - 1;
            } else {
                length = _readable.readShort();
            }
            if (length < 0) {
                throw new RuntimeException("non-nullable field key was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field key had invalid length " + length);
            } else {
                this.key = _readable.readString(length);
            }
        } else {
            this.key = "";
        }
        if (_version >= 1) {
            this.keyType = _readable.readByte();
        } else {
            this.keyType = (byte) 0;
        }
        if (_version >= 4) {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field coordinatorKeys was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<String> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    int length;
                    length = _readable.readUnsignedVarint() - 1;
                    if (length < 0) {
                        throw new RuntimeException("non-nullable field coordinatorKeys element was serialized as null");
                    } else if (length > 0x7fff) {
                        throw new RuntimeException("string field coordinatorKeys element had invalid length " + length);
                    } else {
                        newCollection.add(_readable.readString(length));
                    }
                }
                this.coordinatorKeys = newCollection;
            }
        } else {
            this.coordinatorKeys = new ArrayList<String>(0);
        }
        this._unknownTaggedFields = null;
        if (_version >= 3) {
            int _numTaggedFields = _readable.readUnsignedVarint();
            for (int _i = 0; _i < _numTaggedFields; _i++) {
                int _tag = _readable.readUnsignedVarint();
                int _size = _readable.readUnsignedVarint();
                switch (_tag) {
                    default:
                        this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                        break;
                }
            }
        }
    }
    
    @Override
    public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        if (_version <= 3) {
            {
                byte[] _stringBytes = _cache.getSerializedValue(key);
                if (_version >= 3) {
                    _writable.writeUnsignedVarint(_stringBytes.length + 1);
                } else {
                    _writable.writeShort((short) _stringBytes.length);
                }
                _writable.writeByteArray(_stringBytes);
            }
        } else {
            if (!this.key.equals("")) {
                throw new UnsupportedVersionException("Attempted to write a non-default key at version " + _version);
            }
        }
        if (_version >= 1) {
            _writable.writeByte(keyType);
        } else {
            if (this.keyType != (byte) 0) {
                throw new UnsupportedVersionException("Attempted to write a non-default keyType at version " + _version);
            }
        }
        if (_version >= 4) {
            _writable.writeUnsignedVarint(coordinatorKeys.size() + 1);
            for (String coordinatorKeysElement : coordinatorKeys) {
                {
                    byte[] _stringBytes = _cache.getSerializedValue(coordinatorKeysElement);
                    _writable.writeUnsignedVarint(_stringBytes.length + 1);
                    _writable.writeByteArray(_stringBytes);
                }
            }
        } else {
            if (!this.coordinatorKeys.isEmpty()) {
                throw new UnsupportedVersionException("Attempted to write a non-default coordinatorKeys at version " + _version);
            }
        }
        RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
        _numTaggedFields += _rawWriter.numFields();
        if (_version >= 3) {
            _writable.writeUnsignedVarint(_numTaggedFields);
            _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
        } else {
            if (_numTaggedFields > 0) {
                throw new UnsupportedVersionException("Tagged fields were set, but version " + _version + " of this message does not support them.");
            }
        }
    }
    
    @Override
    public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        if (_version <= 3) {
            {
                byte[] _stringBytes = key.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'key' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(key, _stringBytes);
                if (_version >= 3) {
                    _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
                } else {
                    _size.addBytes(_stringBytes.length + 2);
                }
            }
        }
        if (_version >= 1) {
            _size.addBytes(1);
        }
        if (_version >= 4) {
            {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(coordinatorKeys.size() + 1));
                for (String coordinatorKeysElement : coordinatorKeys) {
                    byte[] _stringBytes = coordinatorKeysElement.getBytes(StandardCharsets.UTF_8);
                    if (_stringBytes.length > 0x7fff) {
                        throw new RuntimeException("'coordinatorKeysElement' field is too long to be serialized");
                    }
                    _cache.cacheSerializedValue(coordinatorKeysElement, _stringBytes);
                    _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
                }
            }
        }
        if (_unknownTaggedFields != null) {
            _numTaggedFields += _unknownTaggedFields.size();
            for (RawTaggedField _field : _unknownTaggedFields) {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                _size.addBytes(_field.size());
            }
        }
        if (_version >= 3) {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
        } else {
            if (_numTaggedFields > 0) {
                throw new UnsupportedVersionException("Tagged fields were set, but version " + _version + " of this message does not support them.");
            }
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof FindCoordinatorRequestData)) return false;
        FindCoordinatorRequestData other = (FindCoordinatorRequestData) obj;
        if (this.key == null) {
            if (other.key != null) return false;
        } else {
            if (!this.key.equals(other.key)) return false;
        }
        if (keyType != other.keyType) return false;
        if (this.coordinatorKeys == null) {
            if (other.coordinatorKeys != null) return false;
        } else {
            if (!this.coordinatorKeys.equals(other.coordinatorKeys)) return false;
        }
        return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
    }
    
    @Override
    public int hashCode() {
        int hashCode = 0;
        hashCode = 31 * hashCode + (key == null ? 0 : key.hashCode());
        hashCode = 31 * hashCode + keyType;
        hashCode = 31 * hashCode + (coordinatorKeys == null ? 0 : coordinatorKeys.hashCode());
        return hashCode;
    }
    
    @Override
    public FindCoordinatorRequestData duplicate() {
        FindCoordinatorRequestData _duplicate = new FindCoordinatorRequestData();
        _duplicate.key = key;
        _duplicate.keyType = keyType;
        ArrayList<String> newCoordinatorKeys = new ArrayList<String>(coordinatorKeys.size());
        for (String _element : coordinatorKeys) {
            newCoordinatorKeys.add(_element);
        }
        _duplicate.coordinatorKeys = newCoordinatorKeys;
        return _duplicate;
    }
    
    @Override
    public String toString() {
        return "FindCoordinatorRequestData("
            + "key=" + ((key == null) ? "null" : "'" + key.toString() + "'")
            + ", keyType=" + keyType
            + ", coordinatorKeys=" + MessageUtil.deepToString(coordinatorKeys.iterator())
            + ")";
    }
    
    public String key() {
        return this.key;
    }
    
    public byte keyType() {
        return this.keyType;
    }
    
    public List<String> coordinatorKeys() {
        return this.coordinatorKeys;
    }
    
    @Override
    public List<RawTaggedField> unknownTaggedFields() {
        if (_unknownTaggedFields == null) {
            _unknownTaggedFields = new ArrayList<>(0);
        }
        return _unknownTaggedFields;
    }
    
    public FindCoordinatorRequestData setKey(String v) {
        this.key = v;
        return this;
    }
    
    public FindCoordinatorRequestData setKeyType(byte v) {
        this.keyType = v;
        return this;
    }
    
    public FindCoordinatorRequestData setCoordinatorKeys(List<String> v) {
        this.coordinatorKeys = v;
        return this;
    }
}
